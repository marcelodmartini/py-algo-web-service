PATCH: py-algo-web-service
-------------------------
Archivos:
- src/main.py (con endpoint /run-now y botón en la home)

Además, asegurate en requirements.txt:
py-algo-starter @ git+https://github.com/marcelodmartini/py-algo-starter@main
